
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { type Chat } from '@google/genai';
import { startChatSession } from './services/geminiService';
import { type Message, Sender } from './types';
import Header from './components/Header';
import ChatMessage from './components/ChatMessage';
import ChatInput from './components/ChatInput';

const App: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'initial-bot-message',
      sender: Sender.Bot,
      text: "Hello! I'm RaazdanChatbot. How can I help you today?",
    },
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const chatRef = useRef<Chat | null>(null);
  const chatContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatRef.current = startChatSession();
  }, []);

  useEffect(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSendMessage = useCallback(async (inputText: string) => {
    if (!inputText.trim() || isLoading) return;

    setError(null);
    const userMessage: Message = {
      id: `user-${Date.now()}`,
      sender: Sender.User,
      text: inputText,
    };
    setMessages((prevMessages) => [...prevMessages, userMessage]);
    setIsLoading(true);

    const botMessageId = `bot-${Date.now()}`;
    // Add a placeholder for the bot's response
    setMessages((prevMessages) => [
      ...prevMessages,
      { id: botMessageId, sender: Sender.Bot, text: '' },
    ]);

    try {
      if (!chatRef.current) {
        throw new Error('Chat session not initialized.');
      }
      
      const stream = await chatRef.current.sendMessageStream({ message: inputText });

      for await (const chunk of stream) {
        const chunkText = chunk.text;
        setMessages((prevMessages) =>
          prevMessages.map((msg) =>
            msg.id === botMessageId
              ? { ...msg, text: msg.text + chunkText }
              : msg
          )
        );
      }
    } catch (e) {
      const errorMessage = e instanceof Error ? e.message : 'An unknown error occurred.';
      console.error(errorMessage);
      setError(`Error: ${errorMessage}. Please check your API key and network connection.`);
       setMessages((prevMessages) =>
          prevMessages.map((msg) =>
            msg.id === botMessageId
              ? { ...msg, text: `Sorry, I encountered an error. Please try again. \n\nDetails: ${errorMessage}` }
              : msg
          )
        );
    } finally {
      setIsLoading(false);
    }
  }, [isLoading]);

  return (
    <div className="flex flex-col h-screen bg-gray-900 text-white font-sans">
      <Header />
      <main ref={chatContainerRef} className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6">
        {messages.map((message) => (
          <ChatMessage key={message.id} message={message} />
        ))}
      </main>
      <footer className="border-t border-gray-700 p-4 bg-gray-900/80 backdrop-blur-sm">
        {error && <p className="text-red-400 text-sm text-center mb-2">{error}</p>}
        <ChatInput onSendMessage={handleSendMessage} isLoading={isLoading} />
      </footer>
    </div>
  );
};

export default App;
