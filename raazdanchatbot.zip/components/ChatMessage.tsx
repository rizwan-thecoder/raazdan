import React from 'react';
import { type Message, Sender } from '../types';
import { BotIcon, UserIcon, LoadingCubeIcon } from './Icons';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';

interface ChatMessageProps {
  message: Message;
}

const ChatMessage: React.FC<ChatMessageProps> = ({ message }) => {
  const isUser = message.sender === Sender.User;
  const isBotTyping = message.sender === Sender.Bot && message.text === '';

  const containerClasses = `flex items-start gap-4 max-w-4xl mx-auto ${isUser ? 'flex-row-reverse' : ''}`;
  const bubbleClasses = `relative px-5 py-3 rounded-2xl max-w-full md:max-w-2xl lg:max-w-3xl prose prose-invert prose-sm md:prose-base prose-pre:bg-gray-900/70 prose-pre:rounded-lg prose-pre:p-4 ${isUser ? 'bg-blue-600 rounded-br-none' : 'bg-gray-700 rounded-bl-none'}`;
  
  return (
    <div className={containerClasses}>
      <div className={`w-8 h-8 rounded-full flex-shrink-0 flex items-center justify-center ${isUser ? 'bg-blue-500' : 'bg-purple-500'}`}>
        {isUser ? <UserIcon /> : <BotIcon />}
      </div>
      <div className={bubbleClasses}>
        {isBotTyping ? (
          <LoadingCubeIcon />
        ) : (
          <ReactMarkdown remarkPlugins={[remarkGfm]}>
            {message.text}
          </ReactMarkdown>
        )}
      </div>
    </div>
  );
};

export default ChatMessage;
