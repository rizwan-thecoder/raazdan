
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="flex items-center justify-center p-4 bg-gray-900/80 backdrop-blur-sm border-b border-gray-700 shadow-lg">
      <div className="flex items-center space-x-3">
        <div className="w-8 h-8 bg-gradient-to-tr from-purple-500 to-blue-500 rounded-full animate-pulse"></div>
        <h1 className="text-2xl font-bold tracking-wider bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-blue-400">
          RaazdanChatbot
        </h1>
      </div>
    </header>
  );
};

export default Header;
