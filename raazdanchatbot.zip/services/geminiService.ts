
import { GoogleGenAI, Chat } from "@google/genai";

// IMPORTANT: Set your API key in the environment variables.
// Do not hardcode the API key here.
const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  // In a real app, you might show a persistent error message to the user.
  // For this example, we throw an error to halt execution.
  console.error("API_KEY environment variable not set. Please set it to use the Gemini API.");
  // We'll return a mock chat that shows an error instead of throwing, 
  // so the UI can still render and display the issue.
}

const ai = new GoogleGenAI({ apiKey: API_KEY! });

export function startChatSession(): Chat {
  if (!API_KEY) {
     // This is a mock implementation for when the API key is missing.
     // It allows the UI to function and display an error message gracefully.
    return {
      sendMessage: async () => { throw new Error('API Key is missing. Please configure it in your environment variables.') },
      sendMessageStream: async function*() {
        yield { text: 'API Key is missing. Please configure it in your environment variables.' };
      }
    } as unknown as Chat;
  }

  const chat = ai.chats.create({
    model: 'gemini-2.5-flash',
    config: {
      systemInstruction: 'You are RaazdanChatbot, a helpful and friendly AI assistant for personal use. Your responses should be informative, concise, and engaging. Format your responses using markdown.',
    },
  });
  return chat;
}
